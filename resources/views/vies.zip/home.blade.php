<head>

<meta name="csrf-token" content="{{ csrf_token() }}">

</head>
<style>
    .route_btn{
        border-radius:25px;
    }
        .store_div{
        margin: auto!important;

    }
@media only screen and (max-width: 575px) {
    .store_div {
        margin-left: 25%!important;
  }
}
</style>
@extends('main')
		@section('main-content')
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

        <div class="container-fluid position-relative">
       <div class="text-center">
            <a onclick="log('oneway')"  id="one_btn" style="border-radius:25px;background:#F77D0A" class="btn route_btn text-light border-rounded">One Way</a>
            <a onclick="log('round')" id="round_btn"  style="border-radius:25px;background:#F77D0A" class="btn route_btn text-light border-rounded">Round</a>
            <a onclick="log('local')"  id="local_btn" style="border-radius:25px;background:#F77D0A" class="btn route_btn  text-light border-rounded">Local</a>
       </div> 
    </div></br>

    <!-- Search Start -->
    <div class="container-fluid bg-white pt-3 px-lg-5" id="one_way">
        <form action="inquiry_submit" method="post">
            @csrf
            <div class="row mx-n2">

            <div class="col-xl-3 col-lg-6 col-md-6 px-2">
                <small>Select Pickup City</small>

                <select name="start_point" id="select1"  class="custom-select1 px-4 mb-3 multisteps-form__input form-control @error('start_point') is-invalid @enderror" style="height: 50px;">
                    <option value="">Select Pickup City</option>
                    
                    @foreach($cities as $city)
                    <option value="{{$city->city}}">{{$city->city}}</option>
                    @endforeach
                </select>
                @error('start_point')
                <span class="invalid-feedback" >
                    <strong>{{ $message }}</strong>
                </span>
                @enderror
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 px-2">
                <small>Select Drop City</small>

                <select name="end_point" id="select2" class="custom-select2 px-4 mb-3 multisteps-form__input form-control @error('end_point') is-invalid @enderror" style="height: 50px;">
                    <option value="">Select Drop City</option>
                @foreach($cities as $city)
                    <option value="{{$city->city}}">{{$city->city}}</option>
                @endforeach
                </select>
                @error('end_point')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                @enderror
            </div>
           
<?php
$currentDate = date('Y-m-d');

?>
            <div class="col-xl-3 col-lg-6 col-md-6 px-2">
                <div class="time mb-3" id="time" data-target-input="nearest">
                <small>Select Date</small>
                    <input type="date" name="date" min="{{$currentDate}}"  class="form-control p-4 datetimepicker-input multisteps-form__input form-control @error('date') is-invalid @enderror" placeholder="Pickup Date"
                        data-target="#time" data-toggle="datetimepicker" />
                        @error('date')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                @enderror

                </div>
            </div>
           
            <div class="col-xl-3 col-lg-6 col-md-6 px-2">
                    <small>*</small>
                <button class="btn btn-primary btn-block mb-3" type="submit" style="height: 50px;border-color: #f1c40f !important;background:#F77D0A">Check Fare</button>
            </div>
            
        </div>
        </form>
    </div>
    <div class="container-fluid bg-white pt-3 px-lg-5" style="display:none"  id="local">
        <form action="inquiry_local_submit" method="post">
            @csrf
            <div class="row mx-n2">

            <div class="col-xl-3 col-lg-6 col-md-6 px-2">
                <small>Select Pickup City</small>
                <select name="start_point" id="select_local"  class="custom-select1 px-4 mb-3 multisteps-form__input form-control @error('start_point') is-invalid @enderror" style="height: 50px;">
                    <option value="">Select Pickup City</option>
                    
                    @foreach($cities as $city)
                    <option value="{{$city->city}}">{{$city->city}}</option>
                    @endforeach
                </select>
                @error('start_point')
                <span class="invalid-feedback" >
                    <strong>{{ $message }}</strong>
                </span>
                @enderror
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 px-2">
                <small>Select Drop City</small>

                <select name="end_point" id="select_local1" class="custom-select2 px-4 mb-3 multisteps-form__input form-control @error('end_point') is-invalid @enderror" style="height: 50px;">
                    <option value="">Select Drop City</option>
             
                </select>
                @error('end_point')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                @enderror
            </div>
           

            <div class="col-xl-3 col-lg-6 col-md-6 px-2">
                <div class="time mb-3" id="time" data-target-input="nearest">
                    <small>Select Time</small>
                    <input type="time" name="time"  class="form-control p-4 datetimepicker-input multisteps-form__input form-control @error('date') is-invalid @enderror" placeholder="Pickup Date"
                        data-target="#time" data-toggle="datetimepicker" />
                        @error('time')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                @enderror

                </div>
            </div>
           
            <div class="col-xl-3 col-lg-6 col-md-6 px-2">
                    <small>*</small>
                
                <button class="btn btn-primary btn-block mb-3" type="submit" style="height: 50px;border-color: #f1c40f !important;background:#F77D0A">Check Fare</button>
            </div>
            
        </div>
        </form>
    </div>
    <div class="container-fluid bg-white pt-3 px-lg-5" style="display:none" id="round">
        <form action="inquiry_round_submit" method="post">
            @csrf
            <div class="row mx-n2">

            <div class="col-xl-3 col-lg-6 col-md-6 px-2">
                <select name="start_point" id="select1"  class="custom-select1 px-4 mb-3 multisteps-form__input form-control @error('start_point') is-invalid @enderror" style="height: 50px;">
                    <option value="">Select Pickup City</option>
                    
                    @foreach($cities as $city)
                    <option value="{{$city->city}}">{{$city->city}}</option>
                    @endforeach
                </select>
                @error('start_point')
                <span class="invalid-feedback" >
                    <strong>{{ $message }}</strong>
                </span>
                @enderror
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 px-2">

                <select name="end_point" id="select2" class="custom-select2 px-4 mb-3 multisteps-form__input form-control @error('end_point') is-invalid @enderror" style="height: 50px;">
                    <option value="">Select Drop City</option>
                @foreach($cities as $city)
                    <option value="{{$city->city}}">{{$city->city}}</option>
                @endforeach
                </select>
                @error('end_point')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                @enderror
            </div>
           

            <div class="col-xl-3 col-lg-6 col-md-6 px-2">
                <div class="time mb-3" id="time" data-target-input="nearest">
                     <select name="days" id="days" class="custom-select2 px-4 mb-3 multisteps-form__input form-control @error('days') is-invalid @enderror" style="height: 50px;">
                            <option>Select days</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">9</option>
                            <option value="10">10</option>
                        </select>
                        @error('days')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                @enderror

                </div>
            </div>
           
            <div class="col-xl-3 col-lg-6 col-md-6 px-2">
                <button class="btn btn-primary btn-block mb-3" type="submit" style="height: 50px;border-color: #f1c40f !important;background:#F77D0A">Check Fare</button>
            </div>
            
        </div>
        </form>
    </div>
    <!-- Search End -->
   <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 col-sm-2 col-0"></div>
            <div class="col-md-2 col-sm-4 col-6 mb-3 store_div">
                <a target="blank" href="#">
                    <img src="https://oneway.cab/img/google_play_store.png" style="width:100%" alt="download safarmobility.com android app">
                </a>
            </div>
            <br>
            <!-- &nbsp;
            &nbsp; -->
      
            <div class="col-md-2 col-sm-4 col-6 mb-3 store_div">
                <a target="blank" href="#">
                    <img src="https://oneway.cab/img/apple_ios_store.png" style="width:100%" alt="download oneway.cab android app">
                </a>
            </div>
            <div class="col-md-4 col-sm-2 col-0"></div>
           
        </div>
    </div>
    <br>
    <br>
    <br>

    <!-- Carousel Start -->
    <div class="container-fluid p-0" style="margin-bottom: 90px;">
        <div id="header-carousel" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                <img class="w-100"  src="assets/images/t.jpg" alt="Image">

                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 900px;">
                            <h4 class="text-white text-uppercase mb-md-3">Rent A Car</h4>
                            <h1 class="display-1 text-white mb-md-4">Best Rental Cars In Your Location</h1>
                            <a href="inquiry_submitt" class="btn btn-primary py-md-3 px-md-5 mt-2">Reserve Now</a>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                <img class="w-100" src="https://source.unsplash.com/1600x600?cab" alt="Image">

                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 900px;">
                            <h4 class="text-white text-uppercase mb-md-3">Rent A Car</h4>
                            <h1 class="display-1 text-white mb-md-4">Quality Cars with Unlimited Miles</h1>
                            <a href="inquiry_submitt" class="btn btn-primary py-md-3 px-md-5 mt-2">Reserve Now</a>
                        </div>
                    </div>
                </div>
            </div>
            <a class="carousel-control-prev" href="#header-carousel" data-slide="prev">
                <div class="btn btn-dark" style="width: 45px; height: 45px;">
                    <span class="carousel-control-prev-icon mb-n2"></span>
                </div>
            </a>
            <a class="carousel-control-next" href="#header-carousel" data-slide="next">
                <div class="btn btn-dark" style="width: 45px; height: 45px;">
                    <span class="carousel-control-next-icon mb-n2"></span>
                </div>
            </a>
        </div>
    </div>
    <!-- Carousel End -->
    <div class="container-fluid bg-white pt-2 px-lg-5 ">
        
        <div class="card-group">
            
        @php
            $count = count($data);
        @endphp
<div class="container">

                <h3 class="mb-2">ALL Routes</h3>
                <p>Best Taxi/taxi Specialist organization One way Outstation Vehicle Rental Nearby and Air terminal Taxi Administration All Over India</p>
                <br>
            </div></br>
        <div class="row">
        @for ($i = 0; $i < $count; $i++)
   
            @foreach($data[$i] as $d)
          
                <div class="col-lg-4 col-sm-6 text-center">
                    <a href="amt_route?key={{$d->id}}&from={{$d->city}}&to={{$d->to}}">{{$d->city}} To  {{$d->to}} <span style="color: black!important;" class="text-primary">	(₹{{$d->sedan}})</span></a> 
                </div>
                <br>
                <br>
                @endforeach     
                
        @endfor      
        </div>

        </div>
        
    </div></br></br></br></br>
	                      
   
      
    <!-- About Start -->
    <div class="icon-block-left icon-left-v1 border-bottom border-color-8 pb-2 pt-4 mt-1">
        <div class="container">
            <div class="row">
                <!-- Icon Block Left Align -->
                <div class="col-md-4 mt_15">
                    <div class="media pr-xl-14">
                        <img src="assets/img/care.png" style="height:50px" class=" mb-3 mr-3">                 
                            <div class="media-body">
                            <h5 class="font-size-19 text-dark font-weight-bold mb-1"><a href="#">Customer Care</a></h5>
                            <p class="text-gray-1 text-lh-inherit">Our team is working 24*7 to give you the best taxi service. Call on our number anytime.</p>
                        </div>
                    </div>
                </div>
                <!-- End Icon Block Left Align -->

                <!-- Icon Block Left Align -->
                <div class="col-md-4 mt_15">
                    <div class="media pr-xl-14">
                        <img src="assets/img/notes.png" style="height:50px" class=" mb-3 mr-3">           
                            <div class="media-body">
                            <h5 class="font-size-19 text-dark font-weight-bold mb-1"><a href="#">Affordable Rates</a></h5>
                            <p class="text-gray-1 text-lh-inherit">We provide you top-notch taxi service that to in your budget. that's the our major reason why our customer's love our service almost everyday</p>
                        </div>
                    </div>
                </div>
                <!-- End Icon Block Left Align -->

                <!-- Icon Block Left Align -->
                <div class="col-md-4 mt_15">
                    <div class="media pr-xl-14">
                        <img src="assets/img/location.jpeg" style="height:50px" class=" mb-3 mr-3">                        <div class="media-body">
                            <h5 class="font-size-19 text-dark font-weight-bold mb-1"><a href="#">Pick &amp; Drop</a></h5>
                            <p class="text-gray-1 text-lh-inherit">We have almost all type of customers, who want to go to anywhere. therefore, we provide door to door service.</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mt_15">
                    <div class="media pr-xl-14">
                    <img src="assets/img/no_hidden.png" style="height:50px" class=" mb-3 mr-3">
                        <div class="media-body">
                            <h5 class="font-size-19 text-dark font-weight-bold mb-1"><a href="#">No Hidden Charges</a></h5>
                            <p class="text-gray-1 text-lh-inherit">Our prices include taxes and insurance. What you see is what you really pay</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mt_15">
                    <div class="media pr-xl-14">
                        <img src="assets/img/no_limit.png" style="height:50px" class=" mb-3 mr-3">
                        <!-- <i class="flaticon-customer-service text-primary font-size-50 text-lh-1 mb-3 mr-3"></i> -->
                        <div class="media-body">
                            <h5 class="font-size-19 text-dark font-weight-bold mb-1"><a href="#">No Limits</a></h5>
                            <p class="text-gray-1 text-lh-inherit">Drive as much as you want with unlimited kms. Just like your own car!</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mt_15">
                    <div class="media pr-xl-14">
                    <img src="assets/img/2min5.png" style="height:60px" class=" mb-3 mr-3">
                        <div class="media-body">
                            <h5 class="font-size-19 text-dark font-weight-bold mb-1"><a href="#">Booking in 2 Minutes</a></h5>
                            <p class="text-gray-1 text-lh-inherit">No hassle of uploading your driving license and waiting for its approval. Easy enough!</p>
                        </div>
                    </div>
                </div>
                <!-- End Icon Block Left Align -->
            </div>
        </div>
    </div></br>
    <!-- About End -->
    

    <!--how it works-->
    <div class="container text-center space-top-lg-2">
        <!-- Title -->
        <div class="w-md-80 w-lg-50 text-center mx-md-auto pb-1 pt-5 pb-md-6">
            <h2 class="section-title text-black font-size-30 font-weight-bold">How it Works</h2>
        </div></br></br></br>
        <!-- End Title -->
        <!-- Features -->
        <div class="mb-6">
            <div class="row">
                <!-- Icon Block -->
                
                <!-- End Icon Block -->

                <!-- Icon Block -->
              

                <div class="col-lg-3 pb-4 pb-lg-0">
                    <img class="img-fluid pb-5" src="assets/img/work.1.jpg">
                    <div class="text-lg-left  w-lg-80 mx-auto">
                        <h5 class="font-size-21 text-dark font-weight-bold mb-2"><a href="#">Choose the trip type</a></h5>
                        <p class="text-gray-1">Intercity, Local or Airport Transfer</p>
                    </div>
                </div>
                <!-- End Icon Block -->

                <!-- Icon Block -->
                <div class="col-lg-3 pb-4 pb-lg-0">
                    <img class="img-fluid pb-5" src="assets/img/work.3.png">
                        <div class="text-lg-left w-lg-80 mx-auto">
                            <h5 class="font-size-21 text-dark font-weight-bold mb-2"><a href="#">Select a car</a></h5>
                            <p class="text-gray-1">from Hatchbacks, sedan, Innovas, luxury cars and Tempo Travellers</p>
                        </div>
                </div>

                <div class="col-lg-3 pb-4 pb-lg-0">
                    <img class="img-fluid pb-5" src="assets/img/work.2.jpg">
                    <div class="text-lg-left w-lg-80 ml-auto">
                        <h5 class="font-size-21 text-dark font-weight-bold mb-2"><a href="#">Enter your trip details</a></h5>
                        <p class="text-gray-1">date, time and your itirary</p>
                    </div>
                </div>
                <div class="col-lg-3 pb-4 pb-lg-0">
                    <img class="img-fluid pb-5" src="assets/img/work.4.jpg">
                        <div class="text-lg-left w-lg-80 mx-auto">
                            <h5 class="font-size-21 text-dark font-weight-bold mb-2"><a href="#">Pay before trip or after trip</a></h5>
                            <p class="text-gray-1">using your card,cash or e-wallets</p>
                        </div>
                </div>
                <!-- End Icon Block -->
            </div>
        </div>
        <!-- End Features -->
    </div>    <!-- end how it works-->


    <!-- Services Start -->
    <!--<div class="container-fluid py-5">-->
    <!--    <div class="container pt-5 pb-3">-->
    <!--        <h2 class=" text-uppercase text-center mb-5">Our Services</h2>-->
    <!--        <div class="row">-->
    <!--            <div class="col-lg-4 col-md-7 mb-2">-->
    <!--                <div class="service-item d-flex flex-column justify-content-center px-8 mb-8">-->
    <!--                    <img src="assets/img/service1.png" alt="service image">-->
    <!--                    <div class="service-item1   ">-->
    <!--                    <h4 class="text-uppercase mb-5">city transport</h4>-->
    <!--                    <p class="m-0">Kasd dolor no lorem nonumy sit labore tempor at justo rebum rebum stet, justo elitr dolor amet sit sea sed</p></br>-->
                        <!-- <p class=" mb-0 d-block text-center"><a href="detail.html" class="btn btn-primary py-2 mr-1">Read More</a> </p> -->
    <!--                </div>-->
    <!--            </div>-->
    <!--            </div>-->
    <!--            <div class="col-lg-4 col-md-6 mb-2">-->
    <!--                <div class="service-item  d-flex flex-column justify-content-center px-8 mb-4">-->
    <!--                    <img src="assets/img/service2.png" alt="service image">-->
    <!--                    <div class="service-item1   ">-->
    <!--                    <h4 class="text-uppercase mb-5">bussiness trip</h4>-->
    <!--                    <p class="m-0">Kasd dolor no lorem nonumy sit labore tempor at justo rebum rebum stet, justo elitr dolor amet sit sea sed</p></br>-->
                        <!-- <p class=" mb-0 d-block text-center"><a href="detail.html" class="btn btn-primary py-2 mr-1">Read More</a> </p> -->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-lg-4 col-md-6 mb-2">-->
    <!--                <div class="service-item d-flex flex-column justify-content-center px-8 mb-4">-->
    <!--                    <img src="assets/img/service6.png" alt="service image">-->
    <!--                    <div class="service-item1   ">-->
    <!--                    <h4 class="text-uppercase mb-5">Online booking</h4>-->
    <!--                    <p class="m-0">Kasd dolor no lorem nonumy sit labore tempor at justo rebum rebum stet, justo elitr dolor amet sit sea sed</p>-->
                        <!-- <p class=" mb-0 d-block text-center"><a href="detail.html" class="btn btn-primary py-2 mr-1">Read More</a> </p> -->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-lg-4 col-md-6 mb-2">-->
    <!--                <div class="service-item d-flex flex-column justify-content-center px-8 mb-4">-->
    <!--                    <img src="assets/img/service4.png" alt="service image">-->
    <!--                    <div class="service-item1   ">-->
    <!--                    <h4 class="text-uppercase mb-5">regular journey</h4> -->
    <!--                    <p class="m-0">Kasd dolor no lorem nonumy sit labore tempor at justo rebum rebum stet, justo elitr dolor amet sit sea sed</p>-->
                        <!-- <p class=" mb-0 d-block text-center"><a href="detail.html" class="btn btn-primary py-2 mr-1">Read More</a> </p> -->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-lg-4 col-md-6 mb-2">-->
    <!--                <div class="service-item d-flex flex-column justify-content-center px-8 mb-4">-->
    <!--                    <img src="assets/img/service5.png" alt="service image">-->
    <!--                    <div class="service-item1   ">-->
    <!--                    <h4 class="text-uppercase mb-5">picnic trip</h4>-->
    <!--                    <p class="m-0">Kasd dolor no lorem nonumy sit labore tempor at justo rebum rebum stet, justo elitr dolor amet sit sea sed</p>-->
                        <!-- <p class=" mb-0 d-block text-center"><a href="detail.html" class="btn btn-primary py-2 mr-1">Read More</a> </p> -->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-lg-4 col-md-6 mb-2">-->
    <!--                <div class="service-item d-flex flex-column justify-content-center px-8 mb-4">-->
    <!--                    <img src="assets/img/service3.png" alt="service image">-->
    <!--                    <div class="service-item1   ">-->
    <!--                    <h4 class="text-uppercase mb-5">regular office</h4>-->
    <!--                    <p class="m-0">Kasd dolor no lorem nonumy sit labore tempor at justo rebum rebum stet, justo elitr dolor amet sit sea sed</p>-->
                        <!-- <p class=" mb-0 d-block text-center"><a href="detail.html" class="btn btn-primary py-2 mr-1">Read More</a> </p> -->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!-- Services End -->

    <!-- Banner Start -->
    <section class="section-b-space animated-section about-section">
        <div class="animation-section">
            <div class="cross po-1"></div>
            <div class="cross po-2"></div>
            <div class="cross po-3"></div>
            <div class="round po-4"></div>
            <div class="round po-5"></div>
            <div class="round r-2 po-6"></div>
            <div class="round r-2 po-7"></div>
            <div class="round r-y po-8"></div>
            <div class="round r-y po-9"></div>
            <div class="square po-10"></div>
            <div class="square po-11"></div>
            <div class="square s-2 po-12"></div>
        </div>
        <div class="container" id="booking">
            <div class="w-md-80 w-lg-50 text-center mx-md-auto pb-1 pt-5 pb-md-6">
                <h2 class="text-primary text-center">Best</h2>

                <h2 class="section-title text-black font-size-30 font-weight-bold">On Call Booking</h2>
            </div></br></br></br>
            <div class="row">
                <div class="card-group">
                    <div class="col-xl-4 col-lg-4 col-md-6 px-2">
                        <img src="assets/img/emargancy.1.jpg" class="card-img-top" alt="...">
                       
                     </div>
                     <div class="col-xl-4 col-lg-4 col-md-6 px-2">
                        <img src="assets/img/emargancy.2.jpg" class="card-img-top" alt="...">
                       
                     </div>
                          
                <div class="col-lg-4">
                    <div class="about-text">
                        <div >
                            <h5><span>new</span> offer...</h5>
                            <h3>Call Safar to Book a cab</h3>
                            <h2><a href="tel:+91972-7777-393">9638502459</a></h2>
                            <p>Enjoy the most exceptional intercity travel experience with 24 X 7 customer support service at disposal.</p>
                            <a href="inquiry_submitt" class="btn btn-primary">Book a Ride</a>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="row mx-0">
                <div class="col-sm-12 col-xl-12">
                    <div class="px-5  d-flex align-items-center justify-content-between" style="height: 350px;background:#F77D0A">
                        <img class="img-fluid flex-shrink-0 ml-n5 w-50 mr-1" src="assets/img/item.2.png" alt="">
                        <div class="text-center">
                            <h3 class="text-uppercase text-dark mb-3">Looking for a car?</h3>
                            <a class="btn btn-warning py-2 px-4" href="inquiry_submitt">Start Now</a>
                        </div>
                    </div>
                </div>
             
            </div>
        </div>
    </div>
    <!-- Banner End -->


    <!-- Testimonial Start -->
    
    <!-- Testimonial End -->


    <!-- Contact Start -->
    <div class="container-fluid py-5">
        <div class="container pt-5 pb-3">
            <h2 class=" text-uppercase text-center mb-5">Contact Us</h2>
            <div class="row">
                <div class="col-lg-7 mb-2">
                    <div class="contact-form bg-light mb-4" style="padding: 30px;">
                    <form action="contact_mail" method="post">
                    @csrf

                            <div class="row">
                                <div class="col-6 form-group">
                                    <input type="text" class="form-control p-4" name="name" placeholder="Your Name" required="required">
                                </div>
                                <div class="col-6 form-group">
                                    <input type="number" class="form-control p-4" name="number" placeholder="Your Number" required="required">
                                </div>
                            </div>

                            <div class="form-group">
                                <textarea class="form-control py-3 px-4" name="msg" rows="5" placeholder="Message" required="required"></textarea>
                            </div>
                            <div>
                                <button class="btn btn-primary py-3 px-5" type="submit">Send Message</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-5 mb-2">
                    <div class="d-flex flex-column justify-content-center px-5 mb-4" style="height: 435px;background:#F77D0A">
                        <div class="d-flex mb-3">
                            <i class="fa fa-2x fa-map-marker-alt text-warning flex-shrink-0 mr-3"></i>
                            <div class="mt-n1">
                                <h5 class="text-dark">Head Office</h5>
                                <p>131, Sovereign Shoppers, Anand Mahal Road, NR.Shindhu Seva Samiti School, Adajan. Surat. 395009</p>
                            </div>
                        </div>
                        <div class="d-flex mb-3">
                            <i class="fa fa-2x fa-map-marker-alt text-warning flex-shrink-0 mr-3"></i>
                            <div class="mt-n1">
                                <h5 class="text-dark">Branch Office</h5>
                                <p>131, Sovereign Shoppers, Anand Mahal Road, NR.Shindhu Seva Samiti School, Adajan. Surat. 395009</p>
                            </div>
                        </div>
                        <div class="d-flex mb-3">
                            <i class="fa fa-2x fa-envelope-open text-warning flex-shrink-0 mr-3"></i>
                            <div class="mt-n1">
                                <h5 class="text-dark">Customer Service</h5>
                                <p>safarmobility@gmail.com</p>
                            </div>
                        </div>
                        <div class="d-flex">
                            <i class="fa fa-2x fa-envelope-open text-warning flex-shrink-0 mr-3"></i>
                            <div class="mt-n1">
                                <h5 class="text-dark">Return & Refund</h5>
                                <p class="m-0">safarmobility@gmail.com</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @if (\Session::has('undefined_route'))
        <script>
            alert('NOT Available');
        </script>
      @endif
    @if(session('paid'))
        <script>
            alert('Payment Successfully');
        </script>
      @endif
    <!-- Contact End -->


    <!-- Vendor Start -->
   <!----- <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="owl-carousel vendor-carousel">
                <div class="bg-light p-5">
                    <img src="assets/img/Category1.png" alt="">
                </div>
                <div class="bg-light p-4">
                    <img src="assets/img/vendor-2.png" alt="">
                </div>
                <div class="bg-light p-4">
                    <img src="assets/img/vendor-3.png" alt="">
                </div>
                <div class="bg-light p-4">
                    <img src="assets/img/vendor-4.png" alt="">
                </div>
                <div class="bg-light p-4">
                    <img src="assets/img/vendor-5.png" alt="">
                </div>
                <div class="bg-light p-4">
                    <img src="assets/img/vendor-6.png" alt="">
                </div>
                <div class="bg-light p-4">
                    <img src="assets/img/vendor-7.png" alt="">
                </div>
                <div class="bg-light p-4">
                    <img src="assets/img/vendor-8.png" alt="">
                </div>
            </div>
        </div>
    </div>---->
    <!-- Vendor End -->
    <script>

    $(document).ready(function () {
        $(".custom-select1").change(function () {
            var selectedValue = $(this).val();
            console.log(selectedValue);
            $(".custom-select2").each(function () {
                $("option", this).each(function () {
                    if ($(this).val() === selectedValue) {
                        $(this).prop("disabled", true);
                    } else {
                        $(this).prop("disabled", false);
                    }
                });
            });
        });
        $(".custom-select2").change(function () {
            var selectedValue = $(this).val();
            console.log(selectedValue);
            $(".custom-select1").each(function () {
                $("option", this).each(function () {
                    if ($(this).val() === selectedValue) {
                        $(this).prop("disabled", true);
                    } else {
                        $(this).prop("disabled", false);
                    }
                });
            });
        });
    });

    function log(status) {
        let one_way = document.getElementById("one_way");
        let round = document.getElementById("round");
        let local = document.getElementById("local");

            console.log(status);
            if(status=='oneway'){
                one_way.style.display='block';
                round.style.display='none';
                local.style.display='none';
             $('#local_btn').removeClass('btn-warning');
                $('#round_btn').removeClass('btn-warning');
                $('#local_btn').addClass('btn-outline-warning');
                $('#round_btn').addClass('btn-outline-warning');

                $('#one_btn').removeClass('btn-outline-warning');
                $('#one_btn').addClass('btn-warning');


            }
            if(status=='round'){
                one_way.style.display='none';
                round.style.display='block';
                local.style.display='none';
                
                      $('#one_btn').removeClass('btn-warning');
                $('#local_btn').removeClass('btn-warning');
                $('#local_btn').addClass('btn-outline-warning');
                $('#one_btn').addClass('btn-outline-warning');

                $('#round_btn').removeClass('btn-outline-warning');
                $('#round_btn').addClass('btn-warning');

            }
            if(status=='local'){
                one_way.style.display='none';
                round.style.display='none';
                local.style.display='block';
                $('#one_btn').removeClass('btn-warning');
                $('#round_btn').removeClass('btn-warning');
                $('#one_btn').addClass('btn-outline-warning');
                $('#round_btn').addClass('btn-outline-warning');

                $('#local_btn').removeClass('btn-outline-warning');
                $('#local_btn').addClass('btn-warning');

            }
};

    </script>
<script type="text/javascript">

var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content'); 

function checkDropdowns() {
    var dropdown1 = document.getElementById('select_local').value;
    var dropdown2 = document.getElementById('select_local1');
    if (dropdown1){
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });

    
      
        $.ajax({
            type: 'post',
            url: 'local_destiny',
            data:  {
                'from': dropdown1,
            },
            dataType: 'json',
            success: function (result) {
                console.log(result);
                dropdown2.innerHTML = '';
               result.forEach(function(rowData) {
                var option = document.createElement("option");
                option.value = rowData.result; // Set the 'value' attribute
                option.text = rowData.result;  // Set the text displayed in the option
                dropdown2.appendChild(option);
            });


            },
            error: function (err) {
                console.log('c',err);
            }
        });
    }

}


document.getElementById('select_local').addEventListener('change', checkDropdowns);

    </script>
   <script>
        let buttons = document.querySelectorAll('.local');

        function selectButton(buttons) {
            console.log(buttons);
            if (selectedButton !== null) {
                selectedButton.classList.remove('selected');
            }

            selectedButton = button;
            selectedButton.classList.add('selected');
        }
    </script>
    <!-- Footer Start -->
    @endsection