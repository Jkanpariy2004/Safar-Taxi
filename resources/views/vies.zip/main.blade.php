<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Safar</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Rubik&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="assets/css/style.css" rel="stylesheet">

</head>
<style>
    @media only screen and (min-width: 992px) {
    #nav_btn {
        display: none!important;
  }
}
</style>

<body>
    <!-- Topbar Start -->
       <div class="container-fluid  py-2 px-lg-5  d-lg-block" style="background:#F77D0A">
        <div class="row">
            <!--<h2>Rajesh Cab</h2>-->
              <div class="col-3 col-lg-6  d-inline-flex align-items-center">

              <img src="assets/img/safar.png" width="80" alt="">
              <button class="navbar-toggler mt-1" id="nav_btn"  onclick="navOpen()">
                <i  class="fa fa-bars"></i>
            </button>
        </div>
                     
            
            <div class="col-9 col-lg-6 text-right pt-1 text-xs-right text-sm-right">
                <div class="d-inline-flex align-items-center">
                    <!-- <a href="/" class="nav-item nav-link text-dark active">Home</a>
                    <br> -->
                    
                        <div class="col-md-12"><a href="tel:9979761975" class="nav-item nav-link text-light active"> <i style="transform: rotate(94deg);" class="fa fa-phone"></i>+91 9979761975</a></div>
                </div>
            </div>
        </div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-light bg-light" style="border-bottom: 1px solid #ffc107;">
<div class="container-fluid">
   
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">

        <li class="nav-item active">
          <a class="nav-link" href="/">Home</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="/aboutus">About</a>
        </li>
        @if(Session::has('userid'))

        <li class="nav-item active">
          <a class="nav-link" href="/logout">Logout</a>
        </li>
        @else
        <li class="nav-item active">
          <a class="nav-link" href="/login">Login</a>
        </li>
        @endif
        <li class="nav-item active">
          <a class="nav-link" href="/contact">Contact</a>
        </li>

      
      </ul>
      <!-- <div class="row mx-2">
     <button class="btn btn-outline-success" data-toggle="modal" data-target="#logmodal">Login</button>
     <button class="btn btn-outline-info" data-toggle="modal" data-target="#sinmodal">Sign up</button>

    </div> -->
</div>
  </div>
</nav>

    
    <!-- Topbar End -->
<br>
<br>
    <!-- Navbar Start -->
   
@section('main-content')
@show

<div class="container-fluid py-5 px-sm-3 px-md-5" style="margin-top: 90px;background:#F77D0A">
        <div class="row pt-5">
            <div class="col-lg-4 col-md-6 mb-5">
                <h4 class="text-uppercase text-dark mb-4">Get In Touch</h4>
                <p class="mb-2"><i class="fa fa-phone-alt text-dark mr-3"></i><a href="tel:9979761975" class="text-dark">9979761975</a></p>
                <p><i class="fa fa-envelope text-dark mr-3"></i>Safar@gmail.com</p>
                <h6 class="text-uppercase text-dark py-2">Follow Us</h6>
                <div class="d-flex justify-content-start">
                    <a class="btn btn-lg btn-dark btn-lg-square mr-2" href="#"><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-lg btn-dark btn-lg-square mr-2" href="#"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-lg btn-dark btn-lg-square mr-2" href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a class="btn btn-lg btn-dark btn-lg-square" href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            <!--<div class="col-lg-3 col-md-6 mb-5">-->
            <!--    <h4 class="text-uppercase text-dark mb-4">Usefull Links</h4>-->
            <!--    <div class="d-flex flex-column justify-content-start">-->
            <!--        <a class="text-body mb-2" href="#"><i class="fa fa-angle-right text-dark mr-2"></i>Private Policy</a>-->
            <!--        <a class="text-body mb-2" href="#"><i class="fa fa-angle-right text-dark mr-2"></i>Term & Conditions</a>-->
            <!--        <a class="text-body mb-2" href="#"><i class="fa fa-angle-right text-dark mr-2"></i>New Member Registration</a>-->
            <!--        <a class="text-body mb-2" href="#"><i class="fa fa-angle-right text-dark mr-2"></i>Affiliate Programme</a>-->
            <!--        <a class="text-body mb-2" href="#"><i class="fa fa-angle-right text-dark mr-2"></i>Return & Refund</a>-->
            <!--        <a class="text-body" href="#"><i class="fa fa-angle-right text-dark mr-2"></i>Help & FQAs</a>-->
            <!--    </div>-->
            <!--</div>-->
            <div class="col-lg-4 col-md-6 mb-5">
                <h4 class="text-uppercase text-dark mb-4">Car Gallery</h4>
                <div class="row mx-n1">
                    <div class="col-4 px-1 mb-2">
                        <a href=""><img class="w-100" src="assets/img/gallery-1.jpg" alt=""></a>
                    </div>
                    <div class="col-4 px-1 mb-2">
                        <a href=""><img class="w-100" src="assets/img/gallery-2.jpg" alt=""></a>
                    </div>
                    <div class="col-4 px-1 mb-2">
                        <a href=""><img class="w-100" src="assets/img/gallery-3.jpg" alt=""></a>
                    </div>
                    <div class="col-4 px-1 mb-2">
                        <a href=""><img class="w-100" src="assets/img/gallery-4.jpg" alt=""></a>
                    </div>
                    <div class="col-4 px-1 mb-2">
                        <a href=""><img class="w-100" src="assets/img/gallery-5.jpg" alt=""></a>
                    </div>
                    <div class="col-4 px-1 mb-2">
                        <a href=""><img class="w-100" src="assets/img/gallery-6.jpg" alt=""></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 mb-5">
                <h4 class="text-uppercase text-dark mb-4">Newsletter</h4>
                <p class="mb-4 text-dark">Volup amet magna clita tempor. Tempor sea eos vero ipsum. Lorem lorem sit sed elitr sed kasd et</p>
                <div class="w-100 mb-3">
                    <div class="input-group">
                        <input type="text" class="form-control bg-dark border-dark" style="padding: 25px;" placeholder="Your Email">
                        <div class="input-group-append">
                            <button class="btn btn-warning text-dark text-uppercase px-3">Sign Up</button>
                        </div>
                    </div>
                </div>
                <i class="text-dark">Lorem sit sed elitr sed kasd et</i>
            </div>
        </div>
    </div>
    <div class="container-fluid bg-dark py-4 px-sm-3 px-md-5">
        <p class="mb-2 text-center text-dark text-body">&copy; <a href="#">Safar</a>. All Rights Reserved.</p>
		
		<!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->					
        <p class="m-0 text-center text-dark text-body">Designed by <a href="https://bitinfotechnology.com/">Bitinfo Technology</a></p>
    </div>
    <!-- Footer End -->
    

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="assets/js/main.js"></script>
     <script>
        function navOpen(){
            let navbarSupportedContent = document.getElementById('navbarSupportedContent');

            if (navbarSupportedContent.style.display === 'block' || navbarSupportedContent.style.display === '') {
            navbarSupportedContent.style.display = 'none';
            } else if (navbarSupportedContent.style.display === 'none') {
            navbarSupportedContent.style.display = 'block';
            }
        }
    </script>
</body>

</html>